import java.io.IOException;

public class main {

	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		Client client = new Client("localhost");
	}

}
