import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

public class Client {

	String host;
	int tcpport = 10000;
	int sslport = 20000;
	SSLSocketFactory sslSocketFactory;
	SSLSocket sslSocket;
	DataOutputStream os;
	DataInputStream is;
	BufferedReader br;

	Socket tcpSocket;
	BufferedReader sin;
	PrintStream sout;

	int run = 1;

	public Client(String host) throws IOException, InterruptedException {
		this.host = host;
		br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Client has started.");

		connect();
	}

	public void connect() throws IOException, InterruptedException {
		System.out.println("CLIENT:Please select the connection type (TCP/SSL):");
		String conType = br.readLine();

		if (conType.equalsIgnoreCase("tcp")) {
			System.out.println("CLIENT: TCP Connection is being established...");
			createTCPConnection();
		} else {

			System.out.println("CLIENT: SSL Connection is being established...");
			createSSLConnection();
		}

	}

	public void createTCPConnection() throws UnknownHostException, IOException, InterruptedException {
		tcpSocket = new Socket(host, tcpport);
		sin = new BufferedReader(new InputStreamReader(tcpSocket.getInputStream()));
		sout = new PrintStream(tcpSocket.getOutputStream());

		String message, answer;
		while (run == 1) {
			System.out.println("\n###############################################################");
			System.out.print("CLIENT: ");
			message = br.readLine();
			answer = "";
			while (!answer.equalsIgnoreCase("OK")) {

				sout.println(message);
				if (message.equalsIgnoreCase("BYE")) {
					System.out.println("CLIENT:Connection ended by client");
					break;
				}

				TimeUnit.SECONDS.sleep(2);
				answer = sin.readLine();
				
				if (!answer.equalsIgnoreCase("OK")) {
					if (answer.length() > 5) {
						if (answer.substring(0, 5).equals("ERROR")) {
							//System.out.println(answer.substring(0, 5));
							break;
						}
					} else {
						if(answer.length()>0) {
							//System.out.println("CLIENT: Message recieved:"+answer );
							break;
						}else {
								System.out.println("CLIENT: Server not responding. Resending the message...");
						}
					}
				}
			}
			System.out.println("CLIENT:Successfully submitted");
			System.out.print("CLIENT :Server : " + answer + "\n");

		}
	}

	public void createSSLConnection() throws UnknownHostException, IOException, InterruptedException {
		System.setProperty("javax.net.ssl.trustStore", "myTrustedStore.jts");
		System.setProperty("javax.net.ssl.trustStorePassword", "12345678");
		sslSocketFactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
		sslSocket = (SSLSocket) sslSocketFactory.createSocket(host, sslport);
		// os = new DataOutputStream(sslSocket.getOutputStream());
		// is = new DataInputStream(sslSocket.getInputStream());
		// sin = new BufferedReader(new InputStreamReader(is));
		// sout = new PrintStream(os);

		BufferedReader cin = new BufferedReader(new InputStreamReader(sslSocket.getInputStream()));
		PrintStream cout = new PrintStream(sslSocket.getOutputStream(), true);

		String message, answer;
		while (run == 1) {
			System.out.println("\n###############################################################");
			System.out.print("CLIENT: ");
			message = br.readLine();
			answer = "";
			while (!answer.equalsIgnoreCase("OK")) {

				cout.println(message);
				if (message.equalsIgnoreCase("BYE")) {
					System.out.println("CLIENT:Connection ended by client");
					break;
				}

				TimeUnit.SECONDS.sleep(2);
				answer = cin.readLine();
				
				if (!answer.equalsIgnoreCase("OK")) {
					if (answer.length() > 5) {
						if (answer.substring(0, 5).equals("ERROR")) {
							//System.out.println(answer.substring(0, 5));
							break;
						}
					} else {
						if(answer.length()>0) {
							//System.out.println("CLIENT: Message recieved:"+answer );
							break;
						}else {
								System.out.println("CLIENT: Server not responding. Resending the message...");
						}
					
					}
				}
			}
			System.out.print("CLIENT :Server : " + answer + "\n");

		}
	}

}
