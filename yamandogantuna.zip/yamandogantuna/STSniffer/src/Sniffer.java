import java.util.ArrayList;
import java.util.StringTokenizer;

public class Sniffer{

	static ArrayList<String> hexlist;
	static ArrayList<Integer> indexExc = new ArrayList<Integer>();



	public static void main(String[] args) {

		
		for(int i=17;i<1006;i=i+17) {
			indexExc.add(i);
		
		}
		
		/*String hex2="0000   ff ff ff ff ff ff 34 02 86 15 f1 fd 08 00 45 00 \n" + 
				"0010   00 ae 1a 21 00 00 80 11 ed 67 ac 14 6a 8e ac 14 \n" + 
				"0020   6f ff 44 5c 44 5c 00 9a bb b3 7b 22 70 6f 72 74 \n" + 
				"0030   22 3a 20 31 37 35 30 30 2c 20 22 76 65 72 73 69 \n" + 
				"0040   6f 6e 22 3a 20 5b 32 2c 20 30 5d 2c 20 22 68 6f \n" + 
				"0050   73 74 5f 69 6e 74 22 3a 20 32 34 31 31 34 39 35 \n" + 
				"0060   34 31 34 30 34 36 37 35 36 31 36 36 34 33 33 36 \n" + 
				"0070   30 37 36 33 33 37 38 37 35 33 36 35 37 38 31 38 \n" + 
				"0080   2c 20 22 6e 61 6d 65 73 70 61 63 65 73 22 3a 20 \n" + 
				"0090   5b 31 38 31 37 37 39 36 39 34 34 2c 20 31 35 37 \n" + 
				"00a0   34 35 35 36 35 30 38 5d 2c 20 22 64 69 73 70 6c \n" + 
				"00b0   61 79 6e 61 6d 65 22 3a 20 22 22 7d \n";*/
		
		String hex= "0000   44 03 2c bc d5 ae ac ed 5c 5c 36 cc 08 00 45 00 \n" + 
				"0010   00 39 5b 6e 40 00 80 06 63 9b ac 14 72 f5 ac 14 \n" + 
				"0020   70 97 c3 71 27 10 81 ce 03 b2 38 99 c2 ae 50 18 \n" + 
				"0030   01 00 93 94 00 00 73 75 62 6d 69 74 20 64 65 6e \n" + 
				"0040   65 6d 65 2c 74 63 70 \n" + 
				"";
				

		hexlist = parseHexDump(hex);


		String sourceIP = Integer.toString(hex2decimal(hexlist.get(28)))+
				"."+Integer.toString(hex2decimal(hexlist.get(29)))+
				"."+Integer.toString(hex2decimal(hexlist.get(30)))+
				"."+Integer.toString(hex2decimal(hexlist.get(31)));
		String destinationIP = Integer.toString(hex2decimal(hexlist.get(32)))+
				"."+Integer.toString(hex2decimal(hexlist.get(33)))+
				"."+Integer.toString(hex2decimal(hexlist.get(35)))+
				"."+Integer.toString(hex2decimal(hexlist.get(36)));
		String sourcePort = Integer.toString(hex2decimal(hexlist.get(37)+hexlist.get(38)));
		String destPort = Integer.toString(hex2decimal(hexlist.get(39)+hexlist.get(40)));
	
		System.out.println("Soruce IP: "+sourceIP);
		System.out.println("Destination IP: "+destinationIP);
		System.out.println("Soruce Port: "+sourcePort);
		System.out.println("Destination Port: "+destPort);

		for(int i = 41;i<hexlist.size()-1;i++) {
			if(indexExc.contains(i)) {
				continue;
			}
			
			System.out.print(hexToAscii(hexlist.get(i)));
		}

		
	}

	public static int hex2decimal(String s) {
		String digits = "0123456789ABCDEF";
		s = s.toUpperCase();
		int val = 0;
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			int d = digits.indexOf(c);
			val = 16*val + d;
		}
		return val;
	}

	static ArrayList<String> parseHexDump(String hexDump){
		ArrayList<String> hexlist = new ArrayList<String>();

		StringTokenizer st = new StringTokenizer(hexDump," ");  
		while (st.hasMoreTokens()) {  
			hexlist.add(st.nextToken()); 
		} 
		return hexlist;
	}
	
	private static String hexToAscii(String hexStr) {
	    StringBuilder output = new StringBuilder("");
	     
	    for (int i = 0; i < hexStr.length(); i += 2) {
	        String str = hexStr.substring(i, i + 2);
	        output.append((char) Integer.parseInt(str, 16));
	    }
	     
	    return output.toString();
	}

}